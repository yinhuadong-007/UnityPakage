﻿using System;
using System.Collections.Generic;
using UnityEngine;
/// <summary> 类型转换扩张方法 </summary>
public static class ExtConfig
{   
    /// <summary> IdNum 转换 IdNum_Double </summary>
    public static Config.IdNum_Double ToDouble(this Config.IdNum e) {return new Config.IdNum_Double(){ id = e.id, num = e.num};}
    /// <summary> IdNum_Double 转换 IdNum </summary>
    public static Config.IdNum ToInt(this Config.IdNum_Double e) {return new Config.IdNum(){ id = e.id, num = (int)e.num};}
    /// <summary> IdNumValue 转换 IdNumValue_Double </summary>
    public static Config.IdNumValue_Double ToDouble(this Config.IdNumValue e) {return new Config.IdNumValue_Double(){ id = e.id, num = e.num, value = e.value};}
    /// <summary> IdNumValue_Double 转换 IdNumValue </summary>
    public static Config.IdNumValue ToInt(this Config.IdNumValue_Double e) {return new Config.IdNumValue(){ id = e.id, num = (int)e.num, value = (int)e.value};}

    /// <summary> IdNum[] 转换 IdNum_Double[] </summary>
    public static Config.IdNum_Double[] ToDouble(this Config.IdNum[] e) {Config.IdNum_Double[] result = new Config.IdNum_Double[e.Length];for (int i = 0; i < e.Length; i++) {result[i] = e[i].ToDouble();}return result;}
    /// <summary> IdNum_Double[] 转换 IdNum[] </summary>
    public static Config.IdNum[] ToInt(this Config.IdNum_Double[] e) {Config.IdNum[] result = new Config.IdNum[e.Length];for (int i = 0; i < e.Length; i++) {result[i] = e[i].ToInt();}return result;}
    /// <summary> IdNumValue[] 转换 IdNumValue_Double[] </summary>
    public static Config.IdNumValue_Double[] ToDouble(this Config.IdNumValue[] e) {Config.IdNumValue_Double[] result = new Config.IdNumValue_Double[e.Length];for (int i = 0; i < e.Length; i++) {result[i] = e[i].ToDouble();}return result;}
    /// <summary> IdNumValue_Double[] 转换 IdNumValue[] </summary>
    public static Config.IdNumValue[] ToInt(this Config.IdNumValue_Double[] e) {Config.IdNumValue[] result = new Config.IdNumValue[e.Length];for (int i = 0; i < e.Length; i++) {result[i] = e[i].ToInt();}return result;}
    /// <summary> 去除value值 </summary>
    public static Config.IdNum_Double ToIdNum_Double(this Config.IdNumValue_Double e) {return new Config.IdNum_Double(){ id = e.id, num = e.num};}
    /// <summary> 去除value值 </summary>
    public static Config.IdNum ToIdNum(this Config.IdNumValue e) { return new Config.IdNum(){ id = e.id, num = e.num};}

    /// <summary> idNum[] 通过指定id获取num </summary>
    public static int GetNumById(this Config.IdNum[] e, int id) { for (int i = 0; i < e.Length; i++) if (e[i].id == id) return e[i].num; return 0; }
    /// <summary> IdNum_Double[] 通过指定id获取num </summary>
    public static double GetNumById(this Config.IdNum_Double[] e, int id) { for (int i = 0; i < e.Length; i++) if (e[i].id == id) return e[i].num; return 0; }
    /// <summary> 通过value的值权重，获取随机项 </summary>
    public static Config.IdNumValue GetRandomItemWithWeight(this Config.IdNumValue[] e){ float totalWeight = 0; for (int i = 0; i < e.Length; i++) totalWeight += e[i].value; float randomWeight = UnityEngine.Random.Range(0, totalWeight); float weight = 0; for (int i = 0; i < e.Length; i++){ weight += e[i].value; if (randomWeight <= weight) return e[i]; } return e[0];}
    /// <summary> 通过value的值权重，获取随机项 </summary>
    public static Config.IdNumValue_Double GetRandomItemWithWeight(this Config.IdNumValue_Double[] e){ float totalWeight = 0; for (int i = 0; i < e.Length; i++) totalWeight += e[i].value; float randomWeight = UnityEngine.Random.Range(0, totalWeight); float weight = 0; for (int i = 0; i < e.Length; i++){ weight += e[i].value; if (randomWeight <= weight) return e[i]; } return e[0];}

    /// <summary> 扩展字符串方法-插入参数(应该在插入多语言后使用) </summary>
    public static string JoinArgs(this string e, params object[] args) {return string.Format(e, args);}
}
/// <summary>
/// 功能:配置文件
/// 更新：2023-19-06 14:14:49
/// <summary>
[Serializable]
public class Config : MonoBehaviour{
    /// <summary> 配置数据 </summary>
    public static ConfigRoot data;
    /// <summary> json文件 </summary>
    [Tooltip("json文件")]
    public TextAsset json;
    public ConfigRoot root;
    void Awake(){
        JsonUtility.FromJsonOverwrite(json.text,this.root);
        data = this.root;
    }



    /// <summary> 配置数据接口：描述xxx </summary>
    [Serializable]
    public class B{
        /// <summary> 例int </summary>
        public int id;
        /// <summary> 例float </summary>
        public float scale;
        /// <summary> 例string </summary>
        public string name;
        /// <summary> 例int[] </summary>
        public int[] intList;
        /// <summary> 例float[] </summary>
        public float[] floatList;
        /// <summary> 例string[] </summary>
        public string[] nameList;


        private static Dictionary<int,int> iidic = new Dictionary<int, int>();
        ///<summary> 根据id获取 </summary>
        public static B get(int id){
            if(iidic.ContainsKey(id)){return data.B[iidic[id]];}
            for(int i = 0;i < data.B.Length;i++){ if(data.B[i].id == id){iidic.Add(id,i);return data.B[i];}}
            return null;
        }
        public static int Length{
            get { return data.B.Length; }
        }
        public static B Find(Predicate<B> fn){
            return Array.Find<B>(data.B, fn);
        }
        public static B[] FindAll(Predicate<B> fn){
            return Array.FindAll<B>(data.B, fn);
        }
        public static void ForEach(Action<B> fn){
            Array.ForEach(data.B, fn);
        }
        public static void Sort(IComparer<B> fn){
            Array.Sort(data.B, fn);
        }
        public static B[] GetItems(){
            return data.B;
        }
        //public static B[] CopyItems(){
            //B[] items = new B[data.B.Length];
            //Array.ForEach(data.B, (item)=>{
            //});
            //return data.B;
        //}
    }
    /// <summary> 配置数据接口：描述xxx </summary>
    [Serializable]
    public class C{
        /// <summary> 例int </summary>
        public string id;
        /// <summary> 例float </summary>
        public float scale;
        /// <summary> 例string </summary>
        public string name;
        /// <summary> 例int[] </summary>
        public int[] intList;
        /// <summary> 例float[] </summary>
        public float[] floatList;
        /// <summary> 例string[] </summary>
        public string[] nameList;


        private static Dictionary<string,int> iidic = new Dictionary<string, int>();
        ///<summary> 根据id获取 </summary>
        public static C get(string id){
            if(iidic.ContainsKey(id)){return data.C[iidic[id]];}
            for(int i = 0;i < data.C.Length;i++){ if(data.C[i].id == id){iidic.Add(id,i);return data.C[i];}}
            return null;
        }
        public static int Length{
            get { return data.C.Length; }
        }
        public static C Find(Predicate<C> fn){
            return Array.Find<C>(data.C, fn);
        }
        public static C[] FindAll(Predicate<C> fn){
            return Array.FindAll<C>(data.C, fn);
        }
        public static void ForEach(Action<C> fn){
            Array.ForEach(data.C, fn);
        }
        public static void Sort(IComparer<C> fn){
            Array.Sort(data.C, fn);
        }
        public static C[] GetItems(){
            return data.C;
        }
        //public static C[] CopyItems(){
            //C[] items = new C[data.C.Length];
            //Array.ForEach(data.C, (item)=>{
            //});
            //return data.C;
        //}
    }
    /// <summary> 配置数据接口：描述xxx </summary>
    [Serializable]
    public class A{
        /// <summary> 数据 </summary>
        public static A data{ get{ return Config.data.A; } }

        /// <summary> 例1-整数 </summary>
        public int intVal;
        /// <summary> 例2-浮点数 </summary>
        public float floatVal;
        /// <summary> 例3-字符串 </summary>
        public string strVal;
        /// <summary> 例4-整数列表 </summary>
        public int[] intList;
        /// <summary> 例5-浮点数列表 </summary>
        public float[] floatList;
        /// <summary> 例6-字符串列表 </summary>
        public string[] strList;
    }
    /// <summary> 数据类型-配置根节点 </summary>
    [Serializable]
    public class ConfigRoot{
        /// <summary> 描述xxx </summary>
        public B[] B;
        /// <summary> 描述xxx </summary>
        public C[] C;
        /// <summary> 描述xxx </summary>
        public A A;
    }
}