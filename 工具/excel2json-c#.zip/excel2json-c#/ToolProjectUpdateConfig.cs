using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class ToolProjectUpdateConfig{
    [MenuItem("Tool/Project/UpdateConfig")]
    static void BuildAllAssetBundles_Win64()//进行打包
    {
        //如果不存在Scripts文件夹，就自动创建
        if (!Directory.Exists(Application.dataPath+"/Scripts")){
            Directory.CreateDirectory(Application.dataPath+"/Scripts");
        }
        //如果不存在/Scripts/Provide 文件夹，就自动创建
        if (!Directory.Exists(Application.dataPath+"/Scripts/Provide")){
            Directory.CreateDirectory(Application.dataPath+"/Scripts/Provide");
        }
        //获取项目根目录录
        string projectPath = Application.dataPath;
        //获取上一级目录
        projectPath = projectPath.Substring(0, projectPath.LastIndexOf('/'));
        //获取上一级目录的上一级目录
        projectPath = projectPath.Substring(0, projectPath.LastIndexOf('/'));
        projectPath += "" + "/Config/";
        string fromFileCs = projectPath + "Config.cs";
        string fromFileJson = projectPath + "Config.json";
        string toFileCs = Application.dataPath + "/Scripts/Provide/Config.cs";
        string toFileJson = Application.dataPath + "/Config/Config.json";
        File.Copy(fromFileCs, toFileCs, true);
        File.Copy(fromFileJson, toFileJson, true);
        AssetDatabase.Refresh();
    }

    static void createDir(string dir) {
        dir = Application.dataPath + "/" + dir;
        if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
    }
};

